const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
  name: 'fullpp',
  category: 'owner',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { react } = extra;
      
      // 1. Grab the replied-to message
      const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
      const media = quoted?.imageMessage || quoted?.documentMessage;

      if (!media) {
        return react('❌'); // React with error if no media was replied to
      }

      await react('⏳');

      // 2. Download the raw media exactly as it is
      const stream = await downloadContentFromMessage(media, media.imageMessage ? 'image' : 'document');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      // 3. Push it directly to WhatsApp as your profile picture
      await sock.updateProfilePicture(sock.user.id, buffer);
      
      // 4. Confirm success
      await react('✅');

    } catch (err) {
      console.error('[fullpp cmd] error:', err);
      extra.react('❌');
    }
  }
};